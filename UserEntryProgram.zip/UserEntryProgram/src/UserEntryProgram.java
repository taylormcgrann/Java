import java.util.Scanner;


public class UserEntryProgram {
    static Scanner entryScanner = new Scanner(System.in);
    static UserInfo info;
    public static void main(String[] args) {
        //start of main
        String userId = null;
        String userPassword=null;
        String input = "Y";
        int iOption=0;


        //main user loop begins
        while (input.toUpperCase().equals("Y")) {
            // userId=enterId();
            //userPassword=enterPassword();
            enterId();
            output(userId);
            display(userPassword);
            System.out.println("Id and Password accepted! " +
                    "\nEnter another user  (Y or N): ");
            input = entryScanner.nextLine();
            info= new UserInfo();

        }

    }
//end main

    private static void output(String userId) {
        boolean valid=false;
        System.out.println("Enter userId" + "\nMust at least include 6-10 letters" +
                "\nMust be followed by two numbers" + "\nNo White Space.");
        String id = entryScanner.nextLine();
        //if statement
        while(!valid){
        if (id.trim().length() >= 6 || id.trim().length() <= 12) {
            if (id.matches("[a-zA-Z].*[0-9]{2}")) {
                System.out.println("ID is valid");
                valid=true;
            } else {
                System.out.println("ID entered is invalid" +
                        "\nID must be within 6-10 characters" +
                        "\nID must end with two numbers." +
                        "\n Re-enter.");
                id=entryScanner.nextLine();
            }
            //output loop

        }
            }
    }

    private static void display(String userPassword) {
        boolean valid = false;
        System.out.println("Enter password" + "\n Must be 6-12 characters" +
                "\nMust contain at least one number, " +
                "at least one upper case letter, at least one lower case" +
                "\nNo white space, or special symbols.");
        String password = entryScanner.nextLine();
        while (!valid) {
            if (password.trim().length() >= 6 || password.trim().length() <= 12) {
                if (password.matches("(=?.*[A-Z].*)(=?.*[a-z].*)(=?.*[0-9].*)")) {
                    System.out.println("Password is valid");
                    valid=true;
                } else {
                    System.out.println("Password entered is invalid" +
                            "\npassword must be 6-12 character, include at least " +
                            "\n1 uppercase, at least 1 lower case, and at least 1 number." +
                            "\nRe-enter.");
                    password = entryScanner.nextLine();
                }
            }
        }
    }

    public static int enterId() {
        int iOption = 0;
        String userId;
        boolean valid = false;
        //prompt user for id

        while (!valid) {
            try {
                System.out.println("Enter Option");
                iOption = Integer.parseInt(entryScanner.nextLine());
                if (iOption == 1) {
                    System.out.println("Option entered okay" +
                            "\nPress enter to continue");
                    valid = true;
                } else {
                    if (iOption == 3) {
                        System.out.println("You have chose exit. " +
                                "\nPress enter to exit.");
                        valid = true;
                        entryScanner.nextLine();
                        System.exit(0);
                    } else {
                        System.out.println("option must be 1 or 3\nPress enter to continue.");
                    }
                }
            } catch (Exception e) {
                System.out.println("option must be 1 or 3\n Press enter to continue.");

            }
            entryScanner.nextLine();
        }
        return iOption;

    }
}
