public class UserInfo {
    private String userId;
    private String userPassword;


    //getters
    public String getUserId() { return userId; }

    public void setUserid(String id) {
        this.userId = id;}

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String p) {
        this.userPassword = p;
    }

    public static Boolean validUserId(String userId){
        return userId.matches(".*[a-zA-Z].*[0-9]{2}");
    }
    public static Boolean validPassword(String password){
        return password.matches(".*[A-Z][a-z][0-9].*");
    }
    public UserInfo(String id, String p) {
        setUserid(id);
        setUserPassword(p);
    }



public UserInfo(){
    this.userId="taylor20";
    this.userPassword="Mcgrann1";
}}