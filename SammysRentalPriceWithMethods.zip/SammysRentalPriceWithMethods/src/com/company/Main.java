package com.company;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SammyMotto.displaySplash();
        int iNum;
        iNum = input();
        procedure(iNum);
    }
    public static int input() {
        Scanner myScanner;
        myScanner= new Scanner(System.in);
        int num1;
        System.out.println("Enter minutes rented ");
        return myScanner.nextInt();

    }

    private static void procedure(int num1) {
        int cHours, cMinutes;
        double cTotalCost;
        cHours = num1 / 60;
        cMinutes = num1 % 60;
        cTotalCost = cMinutes + cHours * 40;
        output(cHours, cMinutes, num1, cTotalCost);
    }

    public static void output(int hour, int exMin, int totMin, double Total) {
        System.out.println("Total Min rented " + totMin);
        System.out.println("Total Hours Rented " + hour);
        System.out.println("Extra minutes " + exMin);
        System.out.println("Total cost " + Total);
    }


}