public class RevisedRentalClass {
    // instance variables(stored inside the object)
    private String name;
    private String phone;
    private int totMinutes;
    private int hours;
    private int extraMinutes;

    private double cost;

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public int getTotMinutes() {
        return totMinutes;
    }

    public int getHours() {
        return hours;
    }

    public int getExtraMinutes() {
        return extraMinutes;
    }


    //setters
    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setTotMinutes(int totMinutes) {
        this.totMinutes = totMinutes;
    }



    //class variables
    private static final int RATE = 40;

    //contructor(special method with the same name as the class name;
    public RevisedRentalClass(String name, String phone, int totalMinutes) {
        this.name = name;
        this.phone = phone;
        this.totMinutes = totalMinutes;
    }
    public RevisedRentalClass() {
        this.name = "Mickey Mouse";
        this.phone = "1-800 DISNEY";
        this.totMinutes= 60;
    }
    /* calculates hours, extra minutes and cost */
    public void calc() {
        hours = totMinutes / 60;
        extraMinutes = totMinutes % 60;
        cost = (hours * RATE) + extraMinutes;
    }

    /*
    returns a formatted string from rental
     */
    public String display() {
        return ("Name:" + name + "\nPhone:" + phone + "\nHours: " + hours + "\nextra minutes: " + extraMinutes + "\nCost" + cost);

    }
}


