import javax.swing.*;
public class beach {

    //instance
    private String iBeachName;
    private int iSnowConeQty;
    private double iSnowConePrice;
    private int iCornDogQty;
    private double iCornDogPrice;
    private double Subtotal;
    private double SalesTax;
    private double TotalBill;
    //final variable
    private final double TAX = .505;

    public beach() {
        this.iBeachName = "Rathbun";
        this.iSnowConeQty = 2;
        this.iSnowConePrice = 2;
        this.iCornDogQty = 2;
        this.iCornDogPrice = 2;
    }

    public beach(String bn, int cq, double cp, int dq, double dp) {
        setBeachName(bn);
        setSnowConeQty(cq);
        setSnowConePrice(cp);
        setCornDogQty(dq);
        setCornDogPrice(dp);
    }
//getters

    public String getBeachName() {
        return iBeachName;
    }

    public void setBeachName(String bn) {
        this.iBeachName = bn;
    }

    public int getSnowConeQty() {
        return iSnowConeQty;
    }

    public void setSnowConeQty(int cq) {
        this.iSnowConeQty = cq;
    }

    public double getSnowConePrice() {
        return iSnowConePrice;
    }

    public void setSnowConePrice(double cp) {
        this.iSnowConePrice = cp;
    }

    public int getCornDogQty() {
        return (int) iCornDogQty;
    }

    public void setCornDogQty(int dq) {
        this.iCornDogQty = dq;
    }

    public double getCornDogPrice() {
        return (double) iCornDogPrice;
    }

    public void setCornDogPrice(double dp) {
        this.iCornDogPrice = dp;
    }

    public void calc() {
        Subtotal= (iSnowConePrice*iSnowConeQty)+(iCornDogPrice*iCornDogQty);
        SalesTax=Subtotal* TAX;
        TotalBill=Subtotal+SalesTax;

    }
    //output
    public String display(){
        return ("The subtotal is "+ Subtotal+
                "\nThe tax is "+ SalesTax+
                "\nThe Total sale is "+TotalBill);}
}
