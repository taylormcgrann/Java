import javax.swing.*;

// this program allows users to enter information to get total bill
// created Taylor McGrann 1/6/2020

    public class BeachBumsProgram{

    public static void main(String[] args){
        beach beachOne= new beach();
        String name;
         int dogQty, coneQty, dogPrice, conePrice;

         //call calcs
        beachOne.calc();

        //display
        System.out.println(beachOne.display());

        //input
        name=JOptionPane.showInputDialog(null,"Enter Beach name: ");
        beachOne.setBeachName(name);

        dogQty= Integer.parseInt(JOptionPane.showInputDialog(null,"Enter corn dogs purchased: "));
        beachOne.setCornDogQty(dogQty);

        dogPrice= Integer.parseInt(JOptionPane.showInputDialog(null,"Enter cost of corn dogs: "));
        beachOne.setCornDogPrice(dogPrice);

        coneQty= Integer.parseInt(JOptionPane.showInputDialog(null,"Enter how many snow cones purchased: "));
        beachOne.setSnowConeQty(coneQty);

        conePrice= Integer.parseInt(JOptionPane.showInputDialog(null,"Enter price of snow cones: "));
        beachOne.setSnowConePrice(conePrice);}

        }


