//this programs purpose is to caculate various baskets for longaburger
//Taylor McGrann 1/13/2020

import javax.swing.*;
import java.util.Scanner;

public class LongabergerProgram {
    static BasketBuild basket;
    static Scanner basketScanner = new Scanner(System.in);
    public static void main(String[] args) {
        basket= new BasketBuild();
        //input
        input(basket);
        //calcs
        basket.calc();
        //output
        System.out.println(basket.display());
    }
    public static void input(BasketBuild basket) {
        String orderType, iBasketType, iAccessory, iState;
        int iCustomerType;

        System.out.println("Enter Order type: ");
        orderType = basketScanner.nextLine();

        if (orderType.equals("C"));{
            System.out.println("Enter Basket type: ");
            iBasketType = basketScanner.nextLine();
            basket.setiBasketType(iBasketType);
            System.out.println("Enter accessory type: ");
            iAccessory = basketScanner.nextLine();
            basket.setiAccessory(iAccessory);
            System.out.print("Enter customer type: ");
            iCustomerType = Integer.parseInt(basketScanner.nextLine());
            basket.setiCustomerType(iCustomerType);
            System.out.println("Enter state: ");
            iState = basketScanner.nextLine();
            basket.setiState(iState);
        }
         }

}


//system out print like santa helper variable return







