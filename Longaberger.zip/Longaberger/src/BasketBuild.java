import java.text.DecimalFormat;
import java.time.LocalDate;

public class BasketBuild {
    static String receipt;
    private String orderType;
    private String iBasketType;
    private String iAccessory;
    private String iState;
    private int iCustomerType;
    private double basketCost;
    private double accessoryCost;
    private double taxRate;
    private double discount;
    private double cBasketAmt;
    private double cDiscount;
    private double cSubtotal;
    private double cTax;
    private double cTotalCost;
    private LocalDate date;

    //getters
    public String getOrderType(){
        return orderType;
    }
    public String getiBasketType() {
        return iBasketType;
    }

    public void setiBasketType(String bt) {
        this.iBasketType = bt;
    }

    public String getiAccessory() {
        return iAccessory;
    }

    public void setiAccessory(String a) {
        this.iAccessory = a;
    }

    public int getiCustomerType() {
        return iCustomerType;
    }

    public void setiCustomerType(int ct) {
        this.iCustomerType = ct;
    }

    public String getiState() {
        return iState;
    }

    public void setiState(String st) {
        this.iState = st;
    }


    public BasketBuild(String bt, String a, int ct, String st) {

        setiBasketType(bt);
        setiAccessory(a);
        setiCustomerType(ct);
        setiState(st);

    }
    //default Constructor
    public BasketBuild() {
        this.iBasketType = "U";
        this.iAccessory = "A4";
        this.iCustomerType = '1';
        this.iState = "IA";
    }



    //calcs caculates

    public void calc() {




            switch (iBasketType.toUpperCase()) {
                case "C":
                    System.out.println("Cracker");
                    basketCost = 15.00;
                    break;
                case "W":
                    System.out.println("Wildflower");
                    basketCost = 53.25;
                    break;
                case "K":
                    System.out.println("Key");
                    basketCost = 23.15;
                    break;
                case "M":
                    System.out.println("Magazine");
                    basketCost = 34.20;
                    break;
                case "U":
                    System.out.println("Umbrella");
                    basketCost = 112.77;
                    break;

            }
            switch (iAccessory.toUpperCase()){
                case "A1":
                    System.out.println("Your accessory is a protector");
                   accessoryCost= 4.75;
                   break;
                case "A2":
                    System.out.println("Your accessory is a liner");
                    accessoryCost=8.00;
                    break;
                case "A3":
                    System.out.println("Your accessory is combo");
                    accessoryCost=10.55;
                    break;
                case "A4":
                    System.out.println("No accessory!");
                    accessoryCost=0.00;


          }
                switch(iState.toUpperCase()){
                    case "IA":
                        System.out.println("Iowa");
                        taxRate=.06;
                        break;
                    case "IL":
                        System.out.println("Illinois");
                        taxRate=.625;
                        break;
                    case "MO":
                        System.out.println("Missouri");
                        taxRate=.4225;

                /**if (iState.toUpperCase() == "IA") {
                    taxRate = .06;
                } else {
                    if (iState.toUpperCase() == "IL") {
                        taxRate = .625;
                    } else {
                        if (iState.toUpperCase() == "MO") {
                            taxRate = .4225;
                        }
                    }
                **/
                if (iCustomerType == 1) {
                    System.out.println("Your customer type is Dealer");
                    discount = .50;
                } else {
                    if (iCustomerType == 2)
                        discount = .0;
                    else {
                        if (iCustomerType == 3)
                            System.out.println("Customer type is Bus");
                            discount = .10;
                    }


                }
            }

        //calcs
            cBasketAmt= basketCost +accessoryCost;
            cDiscount= cBasketAmt* discount;
            cSubtotal = cBasketAmt - cDiscount;
            cDiscount = cBasketAmt * discount;
            cTax = cSubtotal * taxRate;
            cTotalCost = cSubtotal + cTax;

}

    public String display() {
        LocalDate date=LocalDate.now();
        
        DecimalFormat df = new DecimalFormat("#.00");
        //receipt
        String oSubtotal =df.format(cSubtotal);
        String oTax =df.format(cTax);
        String oTotalCost = df.format(cTotalCost);


        return  ("Today's Date: "+ date+
                "\n\nReceipt" +
                "\nYour subtotal is:$ " + oSubtotal +
                "\n Your sales tax is:$ " +oTax +
                "\n Your total bill is:$ " + oTotalCost);
    }
}


